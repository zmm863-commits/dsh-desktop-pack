module.exports = require('./win32_x64/koffi.node');
